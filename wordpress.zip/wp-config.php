<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'alawp');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '$erst23441.');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'PqcPiua0$2l0+nK)X=zN`)#{lp4TF2g!-q*z(>d?)BK9K0]lWVbg3OV^2Q.H#Y7,');
define('SECURE_AUTH_KEY',  '|2i#W5}0A:RT@$expBKgs>dEdZ ~a:b4REdpiD;og9QBjI|+H/1Kc|HO<+;gSg<z');
define('LOGGED_IN_KEY',    'i^q=byq8`q5r=.ciDd4=h0F{7ot3 ?r&fMJ,=?[LBL7GWw>-LL2+.%b~K|7A_bO-');
define('NONCE_KEY',        'l@i?r4,%9gpN7=] 1#~A+ vFS1FHy7 jze5[+)3l19BM(Y2/8NWs&?LU-|-##,}1');
define('AUTH_SALT',        '@.J0DUoFl~mhP * 2%hg&$W~;XuM}rDT=COTj|R_%2-}4;-!x:!eAo0h0jgf`Qir');
define('SECURE_AUTH_SALT', '8N0}$5++R-DRTDy+}||0<G4,>iA-mspugC_inVM=e#2WF4V}{I)vAT87o_f]q&*+');
define('LOGGED_IN_SALT',   '?a,At|E~2Y;?B<e@TVJ01~8[y@/vTHYmDzF5{3MY>W8A-BU/X>??A3c!Z6BfjOrd');
define('NONCE_SALT',       '&y1dT *6!!<r)f%{5|M2v)=7[ Qq+b@$[jj;PV#a!<,KPK<Bc8_&-VGix7F|+{8}');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'alawp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

